slack_robot_manager_robots = [
  {
    name: "bmo",
    tag: "APP",
  },
  {
    name: "BMO",
    tag: "APP",
  },
  {
    name: "Review my diff",
    tag: "WORKFLOW",
  },
]